#include <stdio.h>

struct aaa {
	virtual int f(int x) { printf("Inside CPP method - %d\n",x); return 1; }
};

aaa a;

extern "C" void use_aaa(aaa *a)
{
	a->f(4);
}
extern "C" void use_aaa2(aaa *a);
extern "C" void cpptest()
{
	printf("Enter CPP test\n");
	use_aaa(&a);
	use_aaa2(&a);
	printf("Leave CPP test\n");
}


extern "C" void ctest();
main()
{
	cpptest();
	ctest();
}
