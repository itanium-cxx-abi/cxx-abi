#ifndef VTABLE_THUNkBASE_H
#define VTABLE_THUNkBASE_H

/*
 * Thunk based vtable format.
 * The format is an array of functions. The name thunk comes from the fact
 * that thunk functions are created for managing the necessary adjustments of
 * the 'this' value because of multiple inheritence semantics.
 * Every entry is:*/

typedef struct _vtable_entry_layout { 
   void (*method) ();
} vtable_entry_layout;

/* The vtable is:
 * struct vtable {
 *   vtable_entry_layout prologue [???]; // The number of reserved entries varies.
 *   vtable_entry_layout entries [];
 * };
 */
 
#define C_INTERFACE_PROLOGUE(iface)             /* Nothing */
#define C_STDMETHOD_(type, method)              type (*method)
#define C_STDMETHODEX_(type, method, arglist)   type (*method) arglist;
 
/* structured vtable entries */
#define C_VTABLE_PROLOGUE                       /* Nothing. */
#define C_VTABLE_ENTRY(method)                  method
 
/* unstructured ((void *) array) vtable entries and sizes.
 * For thunk based vtables this is the same as the previous. */
#define C_VTABLE_PROLOGUE2                      C_VTABLE_PROLOGUE
#define C_VTABLE_ENTRY2(method)                 C_VTABLE_ENTRY((void*)method)
#define C_VTABLE_PROLOGUE_SIZE2                 0
#define C_VTABLE_ENTRY_SIZE2                    1
#define C_VTABLE_FUNC2(ind)                     C_VTABLE_SIZE2(ind)
 
/* The thunk based compilers don't need to adjust the 'this' pointer. */
#define C_ADJUST_THIS_(iface, This, member)     (This)
 
#endif
