#include <stdio.h>

#include "host_vtable.h"

// This source files assumes that there is a definition
// struct aaa {
//    virtual int f(int x);
// };
// extern "C" void use_aaa(aaa *a);
// We implement an instance of an inheriting class.
// We also implement use_aaa2(aaa *a);

struct bbb;
typedef struct {
	C_INTERFACE_PROLOGUE(aaa)
	C_STDMETHODEX_(int,f,(void* b, int x))
} bbb_vtable;

typedef struct {
	bbb_vtable *vt;
} bbb;

int bbb_f(void* b, int x) {
	printf("Inside C method - %d\n",x); 
}

bbb_vtable vt = {
	C_VTABLE_PROLOGUE
	C_VTABLE_ENTRY2(bbb_f)
};

bbb b = { &vt };

extern void use_aaa(bbb* b);
void use_aaa2(bbb *b)
{
	b->vt->f(b,3);
}

void ctest()
{
	printf("Enter C test\n");
	use_aaa(&b);
	use_aaa2(&b);
	printf("Leave C test\n");
}
