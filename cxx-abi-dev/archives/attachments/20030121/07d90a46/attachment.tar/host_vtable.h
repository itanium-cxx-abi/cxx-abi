#ifndef __HOST_VTABLE_H
#define __HOST_VTABLE_H

/*
typedef _method_pointer_layout
{
    void (*method)(void *);
    int vtaboff;
    int thisoff;
} method_pointer_layout;
*/

enum vtable_layout_consts
{
    VTABLE_PROLOGUE_KEY = 0x12345678
};

// HP uses the thunkbased vtable format.
#include "thunkbase.h"

// Modify the prologue of the vtable. For HP it contains 4 reserved entries.
#undef  C_INTERFACE_PROLOGUE
#undef  C_VTABLE_PROLOGUE
#undef  C_VTABLE_PROLOGUE2
#undef  C_VTABLE_PROLOGUE_SIZE2

#define C_INTERFACE_PROLOGUE(iface)             \
    void (*method_0__)();                       \
    void (*method_1__)();                       \
    void (*method_2__)();                       \
    void (*method_3__)();

#define C_VTABLE_PROLOGUE                       0,0,(void (*)())VTABLE_PROLOGUE_KEY,0,
#define C_VTABLE_PROLOGUE2                      0,0,(void*)VTABLE_PROLOGUE_KEY,0,
#define C_VTABLE_PROLOGUE_SIZE2                 4

#endif
